#pragma once

class CComboTab :
	public CContainerUI
{
public:
	CComboTab(CPaintManagerUI* ppm = NULL);
	~CComboTab(void);
};
