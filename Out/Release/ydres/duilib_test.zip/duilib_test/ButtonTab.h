#pragma once
#include "duidialog.h"
class CButtonTab :
	public CContainerUI
{
public:
public:
	CButtonTab(CPaintManagerUI* ppm = NULL);
};

