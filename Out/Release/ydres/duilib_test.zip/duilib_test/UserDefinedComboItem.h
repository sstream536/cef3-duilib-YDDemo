#pragma once

class CUserDefinedComboItem :
	public CContainerUI
{
public:
	CUserDefinedComboItem(void);
	~CUserDefinedComboItem(void);
};
