#pragma once

class CEditTab :
	public CContainerUI
{
public:
	~CEditTab(void);

	CEditTab (CPaintManagerUI* ppm = NULL);
};
