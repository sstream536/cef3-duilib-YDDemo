#pragma once

class CListTab :
	public CContainerUI
{
public:
	CListTab(CPaintManagerUI* ppm = NULL);
	~CListTab(void);
};
